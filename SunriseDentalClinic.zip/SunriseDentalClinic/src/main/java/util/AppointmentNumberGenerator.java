package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class AppointmentNumberGenerator {

    private static final AtomicInteger COUNTER =
            new AtomicInteger(1);

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private AppointmentNumberGenerator() {
    }

    public static String generate() {

        String timestamp =
                LocalDateTime.now().format(FORMATTER);

        int number = COUNTER.getAndIncrement();

        return "APT-" + timestamp + "-" + number;
    }
}