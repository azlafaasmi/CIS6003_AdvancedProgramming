package util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.regex.Pattern;

public class ValidationUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
            );

    private static final Pattern PHONE_PATTERN =
            Pattern.compile(
                    "^[0-9+\\- ]{7,15}$"
            );

    private ValidationUtil() {
    }

    public static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        return !isEmpty(email)
                && EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean isValidPhone(String phone) {
        return !isEmpty(phone)
                && PHONE_PATTERN.matcher(phone).matches();
    }

    public static boolean isValidPrice(BigDecimal price) {
        return price != null
                && price.compareTo(BigDecimal.ZERO) >= 0;
    }

    public static boolean isFutureOrToday(LocalDate date) {
        return date != null
                && !date.isBefore(LocalDate.now());
    }
}